import HostListPacket from '../../../packets/HostListPacket';
import Player from '../../Player';

// skipcq: JS-0356 | Deepsource Unused variable
export default function (player: Player, packet: HostListPacket): void {
  // Not sending data back to lunar
}
